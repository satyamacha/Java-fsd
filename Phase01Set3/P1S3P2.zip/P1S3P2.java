import java.util.Arrays;
import java.util.Scanner;


public class P1S3P2 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the list: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter the elements of the list:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        int fourthSmallest = findFourthSmallest(arr);

        System.out.println("The fourth smallest element in the list is: " + fourthSmallest);

        scanner.close();
    }

    public static int findFourthSmallest(int[] arr) {
        Arrays.sort(arr); 
        return arr[3]; 
    }
}