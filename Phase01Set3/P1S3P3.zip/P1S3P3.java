import java.util.Scanner;


public class P1S3P3 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        System.out.print("Enter the range [L, R] (0 <= L <= R <= n-1): ");
        int L = scanner.nextInt();
        int R = scanner.nextInt();

        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range!");
        } else {
            int sum = 0;
            for (int i = L; i <= R; i++) {
                sum += arr[i];
            }
            System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
        }

        scanner.close();
    }
}
