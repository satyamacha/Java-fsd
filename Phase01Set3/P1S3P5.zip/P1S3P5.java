import java.util.Scanner;

public class P1S3P5 {
    private static class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node head;

    public P1S3P5() {
        this.head = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    public void delete(int key) {
        Node prev = null;
        Node current = head;

        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        prev.next = current.next;
    }

    public void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        P1S3P5 list = new P1S3P5();

        System.out.print("Enter the number of elements in the linked list: ");
        int n = scanner.nextInt();
        System.out.println("Enter the elements of the linked list:");
        for (int i = 0; i < n; i++) {
            int data = scanner.nextInt();
            list.insert(data);
        }

        System.out.print("Enter the key to delete: ");
        int keyToDelete = scanner.nextInt();

        System.out.println("Original linked list:");
        list.display();

        list.delete(keyToDelete);

        System.out.println("Linked list after deleting first occurrence of " + keyToDelete + ":");
        list.display();

        scanner.close();
    }
}
