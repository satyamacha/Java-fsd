
import java.util.Scanner;
public class StringConversion {

  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();

        StringBuffer stringBuffer = new StringBuffer(userInput);

        StringBuilder stringBuilder = new StringBuilder(userInput);

        System.out.println("\nOriginal String: " + userInput);

        System.out.println("Converted to StringBuffer: " + stringBuffer);

        stringBuilder.append(" (appended text)");

        System.out.println("Modified StringBuilder: " + stringBuilder);
    }
}