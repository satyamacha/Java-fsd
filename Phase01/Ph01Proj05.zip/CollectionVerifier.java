
import java.util.*;
public class CollectionVerifier {

  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // User Input Loop
        while (true) {
            System.out.println("\nCollection Menu:");
            System.out.println("1. Create an ArrayList (ordered, allows duplicates)");
            System.out.println("2. Create a HashSet (unordered, no duplicates)");
            System.out.println("3. Create a TreeSet (ordered, no duplicates)");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character after int input

            switch (choice) {
                case 1:
                    createArrayList(scanner);
                    break;
                case 2:
                    createHashSet(scanner);
                    break;
                case 3:
                    createTreeSet(scanner);
                    break;
                case 4:
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }

    public static void createArrayList(Scanner scanner) {
        System.out.print("Enter elements for the ArrayList (separate by spaces): ");
        String input = scanner.nextLine();
        String[] elements = input.split(" ");

        List<String> arrayList = new ArrayList<>();
        for (String element : elements) {
            arrayList.add(element);
        }

        System.out.println("\nCreated ArrayList:");
        System.out.println(arrayList);
    }

    public static void createHashSet(Scanner scanner) {
        System.out.print("Enter elements for the HashSet (separate by spaces): ");
        String input = scanner.nextLine();
        String[] elements = input.split(" ");

        Set<String> hashSet = new HashSet<>();
        for (String element : elements) {
            hashSet.add(element);
        }

        System.out.println("\nCreated HashSet (duplicates removed):");
        System.out.println(hashSet);
    }

    public static void createTreeSet(Scanner scanner) {
        System.out.print("Enter elements for the TreeSet (separate by spaces): ");
        String input = scanner.nextLine();
        String[] elements = input.split(" ");

        Set<String> treeSet = new TreeSet<>();
        for (String element : elements) {
            treeSet.add(element);
        }

        System.out.println("\nCreated TreeSet (ordered):");
        System.out.println(treeSet);
    }
}