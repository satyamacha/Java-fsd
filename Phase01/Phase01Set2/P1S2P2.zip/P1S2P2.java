
import java.util.Scanner;
public class P1S2P2 {

  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter sleep duration in milliseconds: ");
        long sleepDuration = scanner.nextLong();
        
        System.out.print("Enter wait duration in milliseconds: ");
        long waitDuration = scanner.nextLong();
        
        Thread sleepThread = new Thread(new SleepThread(sleepDuration));
        Thread waitThread = new Thread(new WaitThread(waitDuration));

        sleepThread.start();
        waitThread.start();
        
        scanner.close();
    }
}

class SleepThread implements Runnable {
    private long duration;

    public SleepThread(long duration) {
        this.duration = duration;
    }

    @Override
    public void run() {
        System.out.println("SleepThread is going to sleep for " + duration + " milliseconds.");
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("SleepThread woke up after " + duration + " milliseconds.");
    }
}

class WaitThread implements Runnable {
    private long duration;

    public WaitThread(long duration) {
        this.duration = duration;
    }

    @Override
    public void run() {
        synchronized (this) {
            System.out.println("WaitThread is waiting for " + duration + " milliseconds.");
            try {
                this.wait(duration);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("WaitThread woke up after " + duration + " milliseconds.");
        }
    }
}