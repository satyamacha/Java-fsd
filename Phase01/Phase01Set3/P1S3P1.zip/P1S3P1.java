import java.util.Scanner;

public class P1S3P1 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

       System.out.print("Enter the number of steps to right rotate: ");
        int steps = scanner.nextInt();

        System.out.println("Original Array:");
        printArray(arr);

        rightRotate(arr, steps);

        System.out.println("\nArray after right rotation by " + steps + " steps:");
        printArray(arr);

        scanner.close();
    }

    public static void rightRotate(int[] arr, int steps) {
        int n = arr.length;
        steps = steps % n;

        reverse(arr, 0, n - 1); 
        reverse(arr, 0, steps - 1); 
        reverse(arr, steps, n - 1); 
    }

    public static void reverse(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }

    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}