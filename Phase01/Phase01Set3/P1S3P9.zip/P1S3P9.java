
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class P1S3P9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue<Integer> queue = new LinkedList<>();

        System.out.println("Enter 5 elements separated by spaces:");

        String inputLine = scanner.nextLine();
        String[] elements = inputLine.split(" ");

        for (String element : elements) {
            int num = Integer.parseInt(element);
            queue.offer(num);
        }

        System.out.println("Queue after insertion: " + queue);

        System.out.println("Removing elements from the queue:");
        while (!queue.isEmpty()) {
            int removedElement = queue.poll();
            System.out.println("Removed: " + removedElement);
        }
    }
}
