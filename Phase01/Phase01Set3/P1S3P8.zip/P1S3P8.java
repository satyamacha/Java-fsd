
import java.util.*;

public class P1S3P8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter 5 elements separated by spaces:");
        String input = scanner.nextLine();
        String[] elements = input.split(" ");

        Stack<String> stack = new Stack<>();

        System.out.println("Inserting elements into the stack:");
        for (String element : elements) {
            stack.push(element);
            System.out.println("Pushed: " + element);
        }

        System.out.println("\nRemoving elements from the stack:");
        while (!stack.isEmpty()) {
            String removedElement = stack.pop();
            System.out.println("Popped: " + removedElement);
        }

        scanner.close();
    }
}
