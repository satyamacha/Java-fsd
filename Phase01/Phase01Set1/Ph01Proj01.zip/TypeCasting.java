
import java.util.Scanner;
public class TypeCasting {

  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int intValue = 100;
        double doubleValue = intValue;
        System.out.println("Implicit Type Casting (Widening):");
        System.out.println("int value: " + intValue);
        System.out.println("double value after implicit casting: " + doubleValue);

        System.out.println("\nEnter a double value for explicit type casting (Narrowing):");
        double inputDouble = scanner.nextDouble();

        int castedIntValue = (int) inputDouble; // Explicit casting from double to int

        System.out.println("Explicit Type Casting (Narrowing):");
        System.out.println("double value: " + inputDouble);
        System.out.println("int value after explicit casting: " + castedIntValue);

        scanner.close();
    }
}