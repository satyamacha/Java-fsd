
import java.util.Scanner;
public class InnerClassDemo {

  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the name of the outer class: ");
        String outerClassName = scanner.nextLine();

        System.out.print("Enter the name of the inner class: ");
        String innerClassName = scanner.nextLine();

        Outer obj = new Outer();
        System.out.println("\nOuter Class Object Created!");

        if (obj.hasInnerClass(innerClassName)) {
            System.out.println("Inner class method call (assuming a public method): " + obj.getInnerMessage());
        } else {
            System.out.println("Inner class '" + innerClassName + "' not found in outer class.");
        }
    }

    public static class Outer {

        public String getInnerMessage() {
            Inner inner = new Inner(); // Create an inner class instance
            return inner.getInnerText();
        }

        public boolean hasInnerClass(String name) {
            return name.equals("Inner"); 
            }

        private class Inner {
            public String getInnerText() {
                return "This message is from the inner class!";
            }
        }
    }
}