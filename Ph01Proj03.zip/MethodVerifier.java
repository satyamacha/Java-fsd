
import java.util.Scanner;
public class MethodVerifier {

  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // User Input Loop
        while (true) {
            System.out.println("\nMethod Calling Menu:");
            System.out.println("1. Call Static Method (without object)");
            System.out.println("2. Call Non-Static Method (with object)");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character after int input

            switch (choice) {
                case 1:
                    callStaticMethod();
                    break;
                case 2:
                    callNonStaticMethod(scanner);
                    break;
                case 3:
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }

    public static void callStaticMethod() {
        System.out.println("Calling static method (without object):");
        System.out.println("Static method message: " + SampleClass.getStaticMessage());
    }

    public static void callNonStaticMethod(Scanner scanner) {
        System.out.println("Calling non-static method (with object):");
        System.out.print("Enter a message: ");
        String message = scanner.nextLine();

        SampleClass obj = new SampleClass();
        System.out.println("Non-static method message: " + obj.getNonStaticMessage(message));
    }
}

class SampleClass {

    public static String getStaticMessage() {
        return "This is a static message!";
    }

    public String getNonStaticMessage(String message) {
        return "This is a non-static message: " + message;
    }
}