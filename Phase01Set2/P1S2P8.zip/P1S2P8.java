
class BankAccount {
    private String accountNumber;
    private double balance;

    public BankAccount(String accountNumber) {
        this.accountNumber = accountNumber;
        this.balance = 0;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient funds.");
        }
    }

    public double getBalance() {
        return balance;
    }
}

class SavingsAccount extends BankAccount {
    private double interestRate;

    public SavingsAccount(String accountNumber, double interestRate) {
        super(accountNumber);
        this.interestRate = interestRate;
    }

    @Override
    public void deposit(double amount) {
        super.deposit(amount);
        double interest = amount * interestRate / 100;
        System.out.println("Interest earned: " + interest);
        super.deposit(interest);
    }
}

public class P1S2P8 {
    public static void main(String[] args) {
        BankAccount account1 = new BankAccount("1234567890");
        SavingsAccount account2 = new SavingsAccount("0987654321", 5.0);

        account1.deposit(1000);
        account1.withdraw(500);
        System.out.println("Account 1 Balance: " + account1.getBalance());

        account2.deposit(2000);
        account2.withdraw(1000);
        System.out.println("Account 2 Balance: " + account2.getBalance());
    }
}
