interface Animal {
    void sound();
}

interface Dog extends Animal {
    default void sound() {
        System.out.println("Dog barks");
    }
}

interface Cat extends Animal {
    default void sound() {
        System.out.println("Cat meows");
    }
}

class DogCat implements Dog, Cat {
    @Override
    public void sound() {
       Dog.super.sound(); 
       }
}

public class P1S2P9 {
    public static void main(String[] args) {
        DogCat dogCat = new DogCat();
        dogCat.sound();
        }
}
